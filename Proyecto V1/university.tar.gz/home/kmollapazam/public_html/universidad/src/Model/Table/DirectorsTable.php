<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Directors Model
 *
 * @method \App\Model\Entity\Director newEmptyEntity()
 * @method \App\Model\Entity\Director newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Director[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Director get($primaryKey, $options = [])
 * @method \App\Model\Entity\Director findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Director patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Director[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Director|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Director saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Director[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Director[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Director[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Director[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DirectorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('directors');
        $this->setDisplayField('id_director');
        $this->setPrimaryKey('id_director');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_director')
            ->allowEmptyString('id_director', null, 'create');

        $validator
            ->integer('id_department')
            ->requirePresence('id_department', 'create')
            ->notEmptyString('id_department');

        $validator
            ->scalar('dni_director')
            ->maxLength('dni_director', 8)
            ->requirePresence('dni_director', 'create')
            ->notEmptyString('dni_director');

        $validator
            ->scalar('name_director')
            ->maxLength('name_director', 200)
            ->requirePresence('name_director', 'create')
            ->notEmptyString('name_director');

        $validator
            ->scalar('lastname_director')
            ->maxLength('lastname_director', 200)
            ->requirePresence('lastname_director', 'create')
            ->notEmptyString('lastname_director');

        $validator
            ->scalar('email_director')
            ->maxLength('email_director', 200)
            ->requirePresence('email_director', 'create')
            ->notEmptyString('email_director');

        $validator
            ->scalar('cellphone_director')
            ->maxLength('cellphone_director', 9)
            ->requirePresence('cellphone_director', 'create')
            ->notEmptyString('cellphone_director');

        $validator
            ->boolean('status_director')
            ->allowEmptyString('status_director');

        return $validator;
    }
}
