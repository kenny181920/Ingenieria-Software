<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Course Entity
 *
 * @property int $id_course
 * @property int $id_semester
 * @property int $id_type_course
 * @property string $name_course
 * @property int $credit_course
 * @property int $hours_course
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Course extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_semester' => true,
        'id_type_course' => true,
        'name_course' => true,
        'credit_course' => true,
        'hours_course' => true,
        'created' => true,
        'modified' => true,
    ];
}
