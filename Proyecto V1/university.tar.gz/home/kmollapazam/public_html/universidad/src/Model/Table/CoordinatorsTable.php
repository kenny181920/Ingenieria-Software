<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Coordinators Model
 *
 * @method \App\Model\Entity\Coordinator newEmptyEntity()
 * @method \App\Model\Entity\Coordinator newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Coordinator[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Coordinator get($primaryKey, $options = [])
 * @method \App\Model\Entity\Coordinator findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Coordinator patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Coordinator[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Coordinator|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Coordinator saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Coordinator[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Coordinator[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Coordinator[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Coordinator[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CoordinatorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('coordinators');
        $this->setDisplayField('id_coordinator');
        $this->setPrimaryKey('id_coordinator');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_coordinator')
            ->allowEmptyString('id_coordinator', null, 'create');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->scalar('dni_coordinator')
            ->maxLength('dni_coordinator', 8)
            ->requirePresence('dni_coordinator', 'create')
            ->notEmptyString('dni_coordinator');

        $validator
            ->scalar('name_coordinator')
            ->maxLength('name_coordinator', 200)
            ->requirePresence('name_coordinator', 'create')
            ->notEmptyString('name_coordinator');

        $validator
            ->scalar('lastname_coordinator')
            ->maxLength('lastname_coordinator', 200)
            ->requirePresence('lastname_coordinator', 'create')
            ->notEmptyString('lastname_coordinator');

        $validator
            ->scalar('email_coordinator')
            ->maxLength('email_coordinator', 200)
            ->requirePresence('email_coordinator', 'create')
            ->notEmptyString('email_coordinator');

        $validator
            ->scalar('cellphone_coordinator')
            ->maxLength('cellphone_coordinator', 9)
            ->requirePresence('cellphone_coordinator', 'create')
            ->notEmptyString('cellphone_coordinator');

        $validator
            ->boolean('status_coordinator')
            ->allowEmptyString('status_coordinator');

        return $validator;
    }
}
