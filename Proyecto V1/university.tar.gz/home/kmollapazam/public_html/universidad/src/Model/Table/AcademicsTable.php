<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Academics Model
 *
 * @method \App\Model\Entity\Academic newEmptyEntity()
 * @method \App\Model\Entity\Academic newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Academic[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Academic get($primaryKey, $options = [])
 * @method \App\Model\Entity\Academic findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Academic patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Academic[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Academic|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Academic saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Academic[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Academic[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Academic[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Academic[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class AcademicsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('academics');
        $this->setDisplayField('id_academic');
        $this->setPrimaryKey('id_academic');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_academic')
            ->allowEmptyString('id_academic', null, 'create');

        $validator
            ->integer('id_coordinator')
            ->requirePresence('id_coordinator', 'create')
            ->notEmptyString('id_coordinator');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->integer('year_academic')
            ->requirePresence('year_academic', 'create')
            ->notEmptyString('year_academic');

        $validator
            ->scalar('period_academic')
            ->maxLength('period_academic', 2)
            ->requirePresence('period_academic', 'create')
            ->notEmptyString('period_academic');

        return $validator;
    }
}
