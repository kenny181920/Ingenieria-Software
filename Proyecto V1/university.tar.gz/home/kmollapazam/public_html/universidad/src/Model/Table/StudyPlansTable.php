<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StudyPlans Model
 *
 * @method \App\Model\Entity\StudyPlan newEmptyEntity()
 * @method \App\Model\Entity\StudyPlan newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan get($primaryKey, $options = [])
 * @method \App\Model\Entity\StudyPlan findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\StudyPlan patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StudyPlan saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StudyPlan[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\StudyPlan[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\StudyPlan[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\StudyPlan[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StudyPlansTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('study_plans');
        $this->setDisplayField('id_study_plan');
        $this->setPrimaryKey('id_study_plan');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_study_plan')
            ->allowEmptyString('id_study_plan', null, 'create');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->integer('year_study_plan')
            ->requirePresence('year_study_plan', 'create')
            ->notEmptyString('year_study_plan');

        return $validator;
    }
}
