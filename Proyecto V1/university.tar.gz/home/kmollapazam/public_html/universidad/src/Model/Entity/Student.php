<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Student Entity
 *
 * @property int $id_student
 * @property int $id_school
 * @property string $dni_student
 * @property string $name_student
 * @property string $lastname_student
 * @property string $email_student
 * @property string $address_student
 * @property \Cake\I18n\FrozenTime $birthdate_student
 * @property string $cellphone_student
 * @property bool|null $status_student
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Student extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_school' => true,
        'dni_student' => true,
        'name_student' => true,
        'lastname_student' => true,
        'email_student' => true,
        'address_student' => true,
        'birthdate_student' => true,
        'cellphone_student' => true,
        'status_student' => true,
        'created' => true,
        'modified' => true,
    ];
}
