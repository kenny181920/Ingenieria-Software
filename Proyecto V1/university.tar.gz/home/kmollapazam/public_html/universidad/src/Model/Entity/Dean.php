<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Dean Entity
 *
 * @property int $id_dean
 * @property int $id_faculty
 * @property string $name_dean
 * @property string $lastname_dean
 * @property string $email_dean
 * @property string $cellphone_dean
 * @property bool|null $status_dean
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Dean extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_faculty' => true,
        'name_dean' => true,
        'lastname_dean' => true,
        'email_dean' => true,
        'cellphone_dean' => true,
        'status_dean' => true,
        'created' => true,
        'modified' => true,
    ];
}
