<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Teacher Entity
 *
 * @property int $id_teacher
 * @property string $dni_teacher
 * @property string $name_teacher
 * @property string $lastname_teacher
 * @property string $email_teacher
 * @property string $cellphone_teacher
 * @property bool|null $status_teacher
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Teacher extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dni_teacher' => true,
        'name_teacher' => true,
        'lastname_teacher' => true,
        'email_teacher' => true,
        'cellphone_teacher' => true,
        'status_teacher' => true,
        'created' => true,
        'modified' => true,
    ];
}
