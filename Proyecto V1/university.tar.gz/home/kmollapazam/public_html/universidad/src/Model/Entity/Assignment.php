<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Assignment Entity
 *
 * @property int $id_assignment
 * @property int $id_academic
 * @property int $id_course
 * @property int $id_teacher
 * @property int $id_turn
 * @property int $id_section
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Assignment extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_academic' => true,
        'id_course' => true,
        'id_teacher' => true,
        'id_turn' => true,
        'id_section' => true,
        'created' => true,
        'modified' => true,
    ];
}
