<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * TypesCourses Controller
 *
 * @property \App\Model\Table\TypesCoursesTable $TypesCourses
 * @method \App\Model\Entity\TypesCourse[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TypesCoursesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $typesCourses = $this->paginate($this->TypesCourses);

        $this->set(compact('typesCourses'));
    }

    /**
     * View method
     *
     * @param string|null $id Types Course id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $typesCourse = $this->TypesCourses->get($id, [
            'contain' => [],
        ]);

        $this->set('typesCourse', $typesCourse);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $typesCourse = $this->TypesCourses->newEmptyEntity();
        if ($this->request->is('post')) {
            $typesCourse = $this->TypesCourses->patchEntity($typesCourse, $this->request->getData());
            if ($this->TypesCourses->save($typesCourse)) {
                $this->Flash->success(__('The types course has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The types course could not be saved. Please, try again.'));
        }
        $this->set(compact('typesCourse'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Types Course id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $typesCourse = $this->TypesCourses->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $typesCourse = $this->TypesCourses->patchEntity($typesCourse, $this->request->getData());
            if ($this->TypesCourses->save($typesCourse)) {
                $this->Flash->success(__('The types course has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The types course could not be saved. Please, try again.'));
        }
        $this->set(compact('typesCourse'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Types Course id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $typesCourse = $this->TypesCourses->get($id);
        if ($this->TypesCourses->delete($typesCourse)) {
            $this->Flash->success(__('The types course has been deleted.'));
        } else {
            $this->Flash->error(__('The types course could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
