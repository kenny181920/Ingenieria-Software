<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Director[]|\Cake\Collection\CollectionInterface $directors
 */
?>
<div class="directors index content">
    <?= $this->Html->link(__('New Director'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Directors') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_director') ?></th>
                    <th><?= $this->Paginator->sort('id_department') ?></th>
                    <th><?= $this->Paginator->sort('dni_director') ?></th>
                    <th><?= $this->Paginator->sort('name_director') ?></th>
                    <th><?= $this->Paginator->sort('lastname_director') ?></th>
                    <th><?= $this->Paginator->sort('email_director') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_director') ?></th>
                    <th><?= $this->Paginator->sort('status_director') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($directors as $director): ?>
                <tr>
                    <td><?= $this->Number->format($director->id_director) ?></td>
                    <td><?= $this->Number->format($director->id_department) ?></td>
                    <td><?= h($director->dni_director) ?></td>
                    <td><?= h($director->name_director) ?></td>
                    <td><?= h($director->lastname_director) ?></td>
                    <td><?= h($director->email_director) ?></td>
                    <td><?= h($director->cellphone_director) ?></td>
                    <td><?= h($director->status_director) ?></td>
                    <td><?= h($director->created) ?></td>
                    <td><?= h($director->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $director->id_director]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $director->id_director]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $director->id_director], ['confirm' => __('Are you sure you want to delete # {0}?', $director->id_director)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
