<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Director $director
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Director'), ['action' => 'edit', $director->id_director], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Director'), ['action' => 'delete', $director->id_director], ['confirm' => __('Are you sure you want to delete # {0}?', $director->id_director), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Director'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="directors view content">
            <h3><?= h($director->id_director) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dni Director') ?></th>
                    <td><?= h($director->dni_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name Director') ?></th>
                    <td><?= h($director->name_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Director') ?></th>
                    <td><?= h($director->lastname_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Director') ?></th>
                    <td><?= h($director->email_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cellphone Director') ?></th>
                    <td><?= h($director->cellphone_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Director') ?></th>
                    <td><?= $this->Number->format($director->id_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Department') ?></th>
                    <td><?= $this->Number->format($director->id_department) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($director->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($director->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status Director') ?></th>
                    <td><?= $director->status_director ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
