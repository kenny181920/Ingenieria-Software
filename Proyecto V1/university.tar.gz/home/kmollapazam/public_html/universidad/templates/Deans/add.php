<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Dean $dean
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Deans'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="deans form content">
            <?= $this->Form->create($dean) ?>
            <fieldset>
                <legend><?= __('Add Dean') ?></legend>
                <?php
                    echo $this->Form->control('id_faculty');
                    echo $this->Form->control('name_dean');
                    echo $this->Form->control('lastname_dean');
                    echo $this->Form->control('email_dean');
                    echo $this->Form->control('cellphone_dean');
                    echo $this->Form->control('status_dean');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
