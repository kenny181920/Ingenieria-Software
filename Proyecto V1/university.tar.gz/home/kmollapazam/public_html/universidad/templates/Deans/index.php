<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Dean[]|\Cake\Collection\CollectionInterface $deans
 */
?>
<div class="deans index content">
    <?= $this->Html->link(__('New Dean'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Deans') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_dean') ?></th>
                    <th><?= $this->Paginator->sort('id_faculty') ?></th>
                    <th><?= $this->Paginator->sort('name_dean') ?></th>
                    <th><?= $this->Paginator->sort('lastname_dean') ?></th>
                    <th><?= $this->Paginator->sort('email_dean') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_dean') ?></th>
                    <th><?= $this->Paginator->sort('status_dean') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($deans as $dean): ?>
                <tr>
                    <td><?= $this->Number->format($dean->id_dean) ?></td>
                    <td><?= $this->Number->format($dean->id_faculty) ?></td>
                    <td><?= h($dean->name_dean) ?></td>
                    <td><?= h($dean->lastname_dean) ?></td>
                    <td><?= h($dean->email_dean) ?></td>
                    <td><?= h($dean->cellphone_dean) ?></td>
                    <td><?= h($dean->status_dean) ?></td>
                    <td><?= h($dean->created) ?></td>
                    <td><?= h($dean->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $dean->id_dean]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $dean->id_dean]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $dean->id_dean], ['confirm' => __('Are you sure you want to delete # {0}?', $dean->id_dean)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
