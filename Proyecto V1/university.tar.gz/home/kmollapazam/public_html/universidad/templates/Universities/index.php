<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\University[]|\Cake\Collection\CollectionInterface $universities
 */
?>
<div class="universities index content">
    <?= $this->Html->link(__('New University'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Universities') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_university') ?></th>
                    <th><?= $this->Paginator->sort('ruc_university') ?></th>
                    <th><?= $this->Paginator->sort('name_university') ?></th>
                    <th><?= $this->Paginator->sort('address_university') ?></th>
                    <th><?= $this->Paginator->sort('phone_university') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_university') ?></th>
                    <th><?= $this->Paginator->sort('domain_university') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($universities as $university): ?>
                <tr>
                    <td><?= $this->Number->format($university->id_university) ?></td>
                    <td><?= h($university->ruc_university) ?></td>
                    <td><?= h($university->name_university) ?></td>
                    <td><?= h($university->address_university) ?></td>
                    <td><?= h($university->phone_university) ?></td>
                    <td><?= h($university->cellphone_university) ?></td>
                    <td><?= h($university->domain_university) ?></td>
                    <td><?= h($university->created) ?></td>
                    <td><?= h($university->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $university->id_university]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $university->id_university]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $university->id_university], ['confirm' => __('Are you sure you want to delete # {0}?', $university->id_university)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
