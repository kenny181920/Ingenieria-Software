<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\University $university
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit University'), ['action' => 'edit', $university->id_university], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete University'), ['action' => 'delete', $university->id_university], ['confirm' => __('Are you sure you want to delete # {0}?', $university->id_university), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Universities'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New University'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="universities view content">
            <h3><?= h($university->id_university) ?></h3>
            <table>
                <tr>
                    <th><?= __('Ruc University') ?></th>
                    <td><?= h($university->ruc_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name University') ?></th>
                    <td><?= h($university->name_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Address University') ?></th>
                    <td><?= h($university->address_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone University') ?></th>
                    <td><?= h($university->phone_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cellphone University') ?></th>
                    <td><?= h($university->cellphone_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Domain University') ?></th>
                    <td><?= h($university->domain_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id University') ?></th>
                    <td><?= $this->Number->format($university->id_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($university->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($university->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
