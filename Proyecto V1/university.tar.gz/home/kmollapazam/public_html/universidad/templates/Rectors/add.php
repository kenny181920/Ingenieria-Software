<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Rector $rector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Rectors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="rectors form content">
            <?= $this->Form->create($rector) ?>
            <fieldset>
                <legend><?= __('Add Rector') ?></legend>
                <?php
                    echo $this->Form->control('dni_rector');
                    echo $this->Form->control('id_university');
                    echo $this->Form->control('name_rector');
                    echo $this->Form->control('lastname_rector');
                    echo $this->Form->control('email_rector');
                    echo $this->Form->control('cellphone_rector');
                    echo $this->Form->control('status_rector');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
