<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Rector $rector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $rector->id_rector],
                ['confirm' => __('Are you sure you want to delete # {0}?', $rector->id_rector), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Rectors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="rectors form content">
            <?= $this->Form->create($rector) ?>
            <fieldset>
                <legend><?= __('Edit Rector') ?></legend>
                <?php
                    echo $this->Form->control('dni_rector');
                    echo $this->Form->control('id_university');
                    echo $this->Form->control('name_rector');
                    echo $this->Form->control('lastname_rector');
                    echo $this->Form->control('email_rector');
                    echo $this->Form->control('cellphone_rector');
                    echo $this->Form->control('status_rector');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
