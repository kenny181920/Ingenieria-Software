<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Rector[]|\Cake\Collection\CollectionInterface $rectors
 */
?>
<div class="rectors index content">
    <?= $this->Html->link(__('New Rector'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Rectors') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_rector') ?></th>
                    <th><?= $this->Paginator->sort('dni_rector') ?></th>
                    <th><?= $this->Paginator->sort('id_university') ?></th>
                    <th><?= $this->Paginator->sort('name_rector') ?></th>
                    <th><?= $this->Paginator->sort('lastname_rector') ?></th>
                    <th><?= $this->Paginator->sort('email_rector') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_rector') ?></th>
                    <th><?= $this->Paginator->sort('status_rector') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rectors as $rector): ?>
                <tr>
                    <td><?= $this->Number->format($rector->id_rector) ?></td>
                    <td><?= h($rector->dni_rector) ?></td>
                    <td><?= $this->Number->format($rector->id_university) ?></td>
                    <td><?= h($rector->name_rector) ?></td>
                    <td><?= h($rector->lastname_rector) ?></td>
                    <td><?= h($rector->email_rector) ?></td>
                    <td><?= h($rector->cellphone_rector) ?></td>
                    <td><?= h($rector->status_rector) ?></td>
                    <td><?= h($rector->created) ?></td>
                    <td><?= h($rector->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $rector->id_rector]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $rector->id_rector]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $rector->id_rector], ['confirm' => __('Are you sure you want to delete # {0}?', $rector->id_rector)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
