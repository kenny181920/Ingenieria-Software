<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Assignment[]|\Cake\Collection\CollectionInterface $assignments
 */
?>
<div class="assignments index content">
    <?= $this->Html->link(__('New Assignment'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Assignments') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_assignment') ?></th>
                    <th><?= $this->Paginator->sort('id_academic') ?></th>
                    <th><?= $this->Paginator->sort('id_course') ?></th>
                    <th><?= $this->Paginator->sort('id_teacher') ?></th>
                    <th><?= $this->Paginator->sort('id_turn') ?></th>
                    <th><?= $this->Paginator->sort('id_section') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($assignments as $assignment): ?>
                <tr>
                    <td><?= $this->Number->format($assignment->id_assignment) ?></td>
                    <td><?= $this->Number->format($assignment->id_academic) ?></td>
                    <td><?= $this->Number->format($assignment->id_course) ?></td>
                    <td><?= $this->Number->format($assignment->id_teacher) ?></td>
                    <td><?= $this->Number->format($assignment->id_turn) ?></td>
                    <td><?= $this->Number->format($assignment->id_section) ?></td>
                    <td><?= h($assignment->created) ?></td>
                    <td><?= h($assignment->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $assignment->id_assignment]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $assignment->id_assignment]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $assignment->id_assignment], ['confirm' => __('Are you sure you want to delete # {0}?', $assignment->id_assignment)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
