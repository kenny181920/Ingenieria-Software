<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Section $section
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Section'), ['action' => 'edit', $section->id_section], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Section'), ['action' => 'delete', $section->id_section], ['confirm' => __('Are you sure you want to delete # {0}?', $section->id_section), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Sections'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Section'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="sections view content">
            <h3><?= h($section->id_section) ?></h3>
            <table>
                <tr>
                    <th><?= __('Group Section') ?></th>
                    <td><?= h($section->group_section) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Section') ?></th>
                    <td><?= $this->Number->format($section->id_section) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($section->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($section->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
