<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Semester[]|\Cake\Collection\CollectionInterface $semesters
 */
?>
<div class="semesters index content">
    <?= $this->Html->link(__('New Semester'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Semesters') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_semester') ?></th>
                    <th><?= $this->Paginator->sort('id_study_plan') ?></th>
                    <th><?= $this->Paginator->sort('number_semester') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($semesters as $semester): ?>
                <tr>
                    <td><?= $this->Number->format($semester->id_semester) ?></td>
                    <td><?= $this->Number->format($semester->id_study_plan) ?></td>
                    <td><?= $this->Number->format($semester->number_semester) ?></td>
                    <td><?= h($semester->created) ?></td>
                    <td><?= h($semester->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $semester->id_semester]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $semester->id_semester]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $semester->id_semester], ['confirm' => __('Are you sure you want to delete # {0}?', $semester->id_semester)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
