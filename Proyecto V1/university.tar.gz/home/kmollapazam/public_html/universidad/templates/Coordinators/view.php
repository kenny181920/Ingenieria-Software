<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Coordinator $coordinator
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Coordinator'), ['action' => 'edit', $coordinator->id_coordinator], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Coordinator'), ['action' => 'delete', $coordinator->id_coordinator], ['confirm' => __('Are you sure you want to delete # {0}?', $coordinator->id_coordinator), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Coordinators'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Coordinator'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="coordinators view content">
            <h3><?= h($coordinator->id_coordinator) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dni Coordinator') ?></th>
                    <td><?= h($coordinator->dni_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name Coordinator') ?></th>
                    <td><?= h($coordinator->name_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Coordinator') ?></th>
                    <td><?= h($coordinator->lastname_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Coordinator') ?></th>
                    <td><?= h($coordinator->email_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cellphone Coordinator') ?></th>
                    <td><?= h($coordinator->cellphone_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Coordinator') ?></th>
                    <td><?= $this->Number->format($coordinator->id_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School') ?></th>
                    <td><?= $this->Number->format($coordinator->id_school) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($coordinator->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($coordinator->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status Coordinator') ?></th>
                    <td><?= $coordinator->status_coordinator ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
