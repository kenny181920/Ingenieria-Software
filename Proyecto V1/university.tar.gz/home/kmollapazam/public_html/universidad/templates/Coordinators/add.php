<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Coordinator $coordinator
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Coordinators'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="coordinators form content">
            <?= $this->Form->create($coordinator) ?>
            <fieldset>
                <legend><?= __('Add Coordinator') ?></legend>
                <?php
                    echo $this->Form->control('id_school');
                    echo $this->Form->control('dni_coordinator');
                    echo $this->Form->control('name_coordinator');
                    echo $this->Form->control('lastname_coordinator');
                    echo $this->Form->control('email_coordinator');
                    echo $this->Form->control('cellphone_coordinator');
                    echo $this->Form->control('status_coordinator');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
