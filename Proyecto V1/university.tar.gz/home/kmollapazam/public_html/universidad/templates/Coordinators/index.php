<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Coordinator[]|\Cake\Collection\CollectionInterface $coordinators
 */
?>
<div class="coordinators index content">
    <?= $this->Html->link(__('New Coordinator'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Coordinators') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('id_school') ?></th>
                    <th><?= $this->Paginator->sort('dni_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('name_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('lastname_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('email_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('status_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($coordinators as $coordinator): ?>
                <tr>
                    <td><?= $this->Number->format($coordinator->id_coordinator) ?></td>
                    <td><?= $this->Number->format($coordinator->id_school) ?></td>
                    <td><?= h($coordinator->dni_coordinator) ?></td>
                    <td><?= h($coordinator->name_coordinator) ?></td>
                    <td><?= h($coordinator->lastname_coordinator) ?></td>
                    <td><?= h($coordinator->email_coordinator) ?></td>
                    <td><?= h($coordinator->cellphone_coordinator) ?></td>
                    <td><?= h($coordinator->status_coordinator) ?></td>
                    <td><?= h($coordinator->created) ?></td>
                    <td><?= h($coordinator->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $coordinator->id_coordinator]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $coordinator->id_coordinator]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $coordinator->id_coordinator], ['confirm' => __('Are you sure you want to delete # {0}?', $coordinator->id_coordinator)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
