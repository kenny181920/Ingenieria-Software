<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Academic $academic
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Academic'), ['action' => 'edit', $academic->id_academic], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Academic'), ['action' => 'delete', $academic->id_academic], ['confirm' => __('Are you sure you want to delete # {0}?', $academic->id_academic), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Academics'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Academic'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="academics view content">
            <h3><?= h($academic->id_academic) ?></h3>
            <table>
                <tr>
                    <th><?= __('Period Academic') ?></th>
                    <td><?= h($academic->period_academic) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Academic') ?></th>
                    <td><?= $this->Number->format($academic->id_academic) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Coordinator') ?></th>
                    <td><?= $this->Number->format($academic->id_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School') ?></th>
                    <td><?= $this->Number->format($academic->id_school) ?></td>
                </tr>
                <tr>
                    <th><?= __('Year Academic') ?></th>
                    <td><?= $this->Number->format($academic->year_academic) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($academic->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($academic->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
