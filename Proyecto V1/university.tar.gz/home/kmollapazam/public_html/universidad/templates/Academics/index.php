<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Academic[]|\Cake\Collection\CollectionInterface $academics
 */
?>
<div class="academics index content">
    <?= $this->Html->link(__('New Academic'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Academics') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_academic') ?></th>
                    <th><?= $this->Paginator->sort('id_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('id_school') ?></th>
                    <th><?= $this->Paginator->sort('year_academic') ?></th>
                    <th><?= $this->Paginator->sort('period_academic') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($academics as $academic): ?>
                <tr>
                    <td><?= $this->Number->format($academic->id_academic) ?></td>
                    <td><?= $this->Number->format($academic->id_coordinator) ?></td>
                    <td><?= $this->Number->format($academic->id_school) ?></td>
                    <td><?= $this->Number->format($academic->year_academic) ?></td>
                    <td><?= h($academic->period_academic) ?></td>
                    <td><?= h($academic->created) ?></td>
                    <td><?= h($academic->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $academic->id_academic]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $academic->id_academic]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $academic->id_academic], ['confirm' => __('Are you sure you want to delete # {0}?', $academic->id_academic)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
