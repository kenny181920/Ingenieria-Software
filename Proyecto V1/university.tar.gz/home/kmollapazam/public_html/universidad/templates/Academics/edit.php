<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Academic $academic
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $academic->id_academic],
                ['confirm' => __('Are you sure you want to delete # {0}?', $academic->id_academic), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Academics'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="academics form content">
            <?= $this->Form->create($academic) ?>
            <fieldset>
                <legend><?= __('Edit Academic') ?></legend>
                <?php
                    echo $this->Form->control('id_coordinator');
                    echo $this->Form->control('id_school');
                    echo $this->Form->control('year_academic');
                    echo $this->Form->control('period_academic');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
