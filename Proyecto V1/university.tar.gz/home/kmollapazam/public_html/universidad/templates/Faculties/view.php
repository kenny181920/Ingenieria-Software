<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Faculty $faculty
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Faculty'), ['action' => 'edit', $faculty->id_faculty], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Faculty'), ['action' => 'delete', $faculty->id_faculty], ['confirm' => __('Are you sure you want to delete # {0}?', $faculty->id_faculty), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Faculties'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Faculty'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="faculties view content">
            <h3><?= h($faculty->id_faculty) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Faculty') ?></th>
                    <td><?= h($faculty->name_faculty) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Faculty') ?></th>
                    <td><?= $this->Number->format($faculty->id_faculty) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id University') ?></th>
                    <td><?= $this->Number->format($faculty->id_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($faculty->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($faculty->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
