<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Shift $shift
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Shift'), ['action' => 'edit', $shift->id_turn], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Shift'), ['action' => 'delete', $shift->id_turn], ['confirm' => __('Are you sure you want to delete # {0}?', $shift->id_turn), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Shifts'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Shift'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="shifts view content">
            <h3><?= h($shift->id_turn) ?></h3>
            <table>
                <tr>
                    <th><?= __('Description Turn') ?></th>
                    <td><?= h($shift->description_turn) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Turn') ?></th>
                    <td><?= $this->Number->format($shift->id_turn) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($shift->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($shift->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
