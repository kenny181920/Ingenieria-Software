<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Shift[]|\Cake\Collection\CollectionInterface $shifts
 */
?>
<div class="shifts index content">
    <?= $this->Html->link(__('New Shift'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Shifts') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_turn') ?></th>
                    <th><?= $this->Paginator->sort('description_turn') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($shifts as $shift): ?>
                <tr>
                    <td><?= $this->Number->format($shift->id_turn) ?></td>
                    <td><?= h($shift->description_turn) ?></td>
                    <td><?= h($shift->created) ?></td>
                    <td><?= h($shift->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $shift->id_turn]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $shift->id_turn]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $shift->id_turn], ['confirm' => __('Are you sure you want to delete # {0}?', $shift->id_turn)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
