<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Teacher $teacher
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Teacher'), ['action' => 'edit', $teacher->id_teacher], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Teacher'), ['action' => 'delete', $teacher->id_teacher], ['confirm' => __('Are you sure you want to delete # {0}?', $teacher->id_teacher), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Teachers'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Teacher'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="teachers view content">
            <h3><?= h($teacher->id_teacher) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dni Teacher') ?></th>
                    <td><?= h($teacher->dni_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name Teacher') ?></th>
                    <td><?= h($teacher->name_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Teacher') ?></th>
                    <td><?= h($teacher->lastname_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Teacher') ?></th>
                    <td><?= h($teacher->email_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Cellphone Teacher') ?></th>
                    <td><?= h($teacher->cellphone_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Teacher') ?></th>
                    <td><?= $this->Number->format($teacher->id_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($teacher->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($teacher->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Status Teacher') ?></th>
                    <td><?= $teacher->status_teacher ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
