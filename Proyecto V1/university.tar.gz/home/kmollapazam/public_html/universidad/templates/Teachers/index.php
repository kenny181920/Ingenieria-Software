<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Teacher[]|\Cake\Collection\CollectionInterface $teachers
 */
?>
<div class="teachers index content">
    <?= $this->Html->link(__('New Teacher'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Teachers') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_teacher') ?></th>
                    <th><?= $this->Paginator->sort('dni_teacher') ?></th>
                    <th><?= $this->Paginator->sort('name_teacher') ?></th>
                    <th><?= $this->Paginator->sort('lastname_teacher') ?></th>
                    <th><?= $this->Paginator->sort('email_teacher') ?></th>
                    <th><?= $this->Paginator->sort('cellphone_teacher') ?></th>
                    <th><?= $this->Paginator->sort('status_teacher') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($teachers as $teacher): ?>
                <tr>
                    <td><?= $this->Number->format($teacher->id_teacher) ?></td>
                    <td><?= h($teacher->dni_teacher) ?></td>
                    <td><?= h($teacher->name_teacher) ?></td>
                    <td><?= h($teacher->lastname_teacher) ?></td>
                    <td><?= h($teacher->email_teacher) ?></td>
                    <td><?= h($teacher->cellphone_teacher) ?></td>
                    <td><?= h($teacher->status_teacher) ?></td>
                    <td><?= h($teacher->created) ?></td>
                    <td><?= h($teacher->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $teacher->id_teacher]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $teacher->id_teacher]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $teacher->id_teacher], ['confirm' => __('Are you sure you want to delete # {0}?', $teacher->id_teacher)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
