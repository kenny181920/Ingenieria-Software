<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Course $course
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Course'), ['action' => 'edit', $course->id_course], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Course'), ['action' => 'delete', $course->id_course], ['confirm' => __('Are you sure you want to delete # {0}?', $course->id_course), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Courses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Course'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="courses view content">
            <h3><?= h($course->id_course) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Course') ?></th>
                    <td><?= h($course->name_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Course') ?></th>
                    <td><?= $this->Number->format($course->id_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Semester') ?></th>
                    <td><?= $this->Number->format($course->id_semester) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Type Course') ?></th>
                    <td><?= $this->Number->format($course->id_type_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Credit Course') ?></th>
                    <td><?= $this->Number->format($course->credit_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Hours Course') ?></th>
                    <td><?= $this->Number->format($course->hours_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($course->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($course->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
