<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Course[]|\Cake\Collection\CollectionInterface $courses
 */
?>
<div class="courses index content">
    <?= $this->Html->link(__('New Course'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Courses') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_course') ?></th>
                    <th><?= $this->Paginator->sort('id_semester') ?></th>
                    <th><?= $this->Paginator->sort('id_type_course') ?></th>
                    <th><?= $this->Paginator->sort('name_course') ?></th>
                    <th><?= $this->Paginator->sort('credit_course') ?></th>
                    <th><?= $this->Paginator->sort('hours_course') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $course): ?>
                <tr>
                    <td><?= $this->Number->format($course->id_course) ?></td>
                    <td><?= $this->Number->format($course->id_semester) ?></td>
                    <td><?= $this->Number->format($course->id_type_course) ?></td>
                    <td><?= h($course->name_course) ?></td>
                    <td><?= $this->Number->format($course->credit_course) ?></td>
                    <td><?= $this->Number->format($course->hours_course) ?></td>
                    <td><?= h($course->created) ?></td>
                    <td><?= h($course->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $course->id_course]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $course->id_course]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $course->id_course], ['confirm' => __('Are you sure you want to delete # {0}?', $course->id_course)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
