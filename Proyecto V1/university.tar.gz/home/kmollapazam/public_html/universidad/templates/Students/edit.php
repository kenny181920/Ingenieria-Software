<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Student $student
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $student->id_student],
                ['confirm' => __('Are you sure you want to delete # {0}?', $student->id_student), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Students'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="students form content">
            <?= $this->Form->create($student) ?>
            <fieldset>
                <legend><?= __('Edit Student') ?></legend>
                <?php
                    echo $this->Form->control('id_school');
                    echo $this->Form->control('dni_student');
                    echo $this->Form->control('name_student');
                    echo $this->Form->control('lastname_student');
                    echo $this->Form->control('email_student');
                    echo $this->Form->control('address_student');
                    echo $this->Form->control('birthdate_student');
                    echo $this->Form->control('cellphone_student');
                    echo $this->Form->control('status_student');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
