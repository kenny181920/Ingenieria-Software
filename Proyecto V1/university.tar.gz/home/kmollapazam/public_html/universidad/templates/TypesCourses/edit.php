<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\TypesCourse $typesCourse
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $typesCourse->id_type_course],
                ['confirm' => __('Are you sure you want to delete # {0}?', $typesCourse->id_type_course), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Types Courses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="typesCourses form content">
            <?= $this->Form->create($typesCourse) ?>
            <fieldset>
                <legend><?= __('Edit Types Course') ?></legend>
                <?php
                    echo $this->Form->control('description_type_course');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
