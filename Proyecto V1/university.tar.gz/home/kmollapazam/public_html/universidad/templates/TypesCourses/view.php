<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\TypesCourse $typesCourse
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Types Course'), ['action' => 'edit', $typesCourse->id_type_course], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Types Course'), ['action' => 'delete', $typesCourse->id_type_course], ['confirm' => __('Are you sure you want to delete # {0}?', $typesCourse->id_type_course), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Types Courses'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Types Course'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="typesCourses view content">
            <h3><?= h($typesCourse->id_type_course) ?></h3>
            <table>
                <tr>
                    <th><?= __('Description Type Course') ?></th>
                    <td><?= h($typesCourse->description_type_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Type Course') ?></th>
                    <td><?= $this->Number->format($typesCourse->id_type_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($typesCourse->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($typesCourse->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
