<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DeansFixture
 */
class DeansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_dean' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de decanos', 'precision' => null, 'autoIncrement' => null],
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de facultades', 'precision' => null, 'autoIncrement' => null],
        'name_dean' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del decano.', 'precision' => null],
        'lastname_dean' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellido del decano.', 'precision' => null],
        'email_dean' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Correo del decano.', 'precision' => null],
        'cellphone_dean' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del decano', 'precision' => null],
        'status_dean' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si el decano esta activo', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.'],
        '_indexes' => [
            'id_faculty' => ['type' => 'index', 'columns' => ['id_faculty'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_dean'], 'length' => []],
            'deans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_faculty'], 'references' => ['faculties', 'id_faculty'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_dean' => 1,
                'id_faculty' => 1,
                'name_dean' => 'Lorem ipsum dolor sit amet',
                'lastname_dean' => 'Lorem ipsum dolor sit amet',
                'email_dean' => 'Lorem ipsum dolor sit amet',
                'cellphone_dean' => 'Lorem i',
                'status_dean' => 1,
                'created' => '2020-05-10 04:00:06',
                'modified' => '2020-05-10 04:00:06',
            ],
        ];
        parent::init();
    }
}
