<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * StudyPlansFixture
 */
class StudyPlansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de planes de estudios', 'autoIncrement' => true, 'precision' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de escuelas', 'precision' => null, 'autoIncrement' => null],
        'year_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Año del plan de estudio.', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_indexes' => [
            'id_school' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_study_plan'], 'length' => []],
            'study_plans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_study_plan' => 1,
                'id_school' => 1,
                'year_study_plan' => 1,
                'created' => '2020-05-10 04:00:56',
                'modified' => '2020-05-10 04:00:56',
            ],
        ];
        parent::init();
    }
}
