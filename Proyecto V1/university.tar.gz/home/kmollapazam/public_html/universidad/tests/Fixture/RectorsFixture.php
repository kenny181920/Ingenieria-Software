<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * RectorsFixture
 */
class RectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_rector' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de Rectores', 'autoIncrement' => true, 'precision' => null],
        'dni_rector' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del Rector', 'precision' => null],
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de universidades', 'precision' => null, 'autoIncrement' => null],
        'name_rector' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del Rector', 'precision' => null],
        'lastname_rector' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del Rector', 'precision' => null],
        'email_rector' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Correo del rector.', 'precision' => null],
        'cellphone_rector' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del rector.', 'precision' => null],
        'status_rector' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si esta activo el rector', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_indexes' => [
            'id_university' => ['type' => 'index', 'columns' => ['id_university'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_rector'], 'length' => []],
            'rectors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_university'], 'references' => ['universities', 'id_university'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_rector' => 1,
                'dni_rector' => 'Lorem ',
                'id_university' => 1,
                'name_rector' => 'Lorem ipsum dolor sit amet',
                'lastname_rector' => 'Lorem ipsum dolor sit amet',
                'email_rector' => 'Lorem ipsum dolor sit amet',
                'cellphone_rector' => 'Lorem i',
                'status_rector' => 1,
                'created' => '2020-05-10 03:59:49',
                'modified' => '2020-05-10 03:59:49',
            ],
        ];
        parent::init();
    }
}
