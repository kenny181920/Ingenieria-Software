<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SemestersFixture
 */
class SemestersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codico unico del semestre', 'autoIncrement' => true, 'precision' => null],
        'id_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de plan de estudios', 'precision' => null, 'autoIncrement' => null],
        'number_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Numero de semestre', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.'],
        '_indexes' => [
            'id_study_plan' => ['type' => 'index', 'columns' => ['id_study_plan'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_semester'], 'length' => []],
            'semesters_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_study_plan'], 'references' => ['study_plans', 'id_study_plan'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_semester' => 1,
                'id_study_plan' => 1,
                'number_semester' => 1,
                'created' => '2020-05-10 04:01:03',
                'modified' => '2020-05-10 04:01:03',
            ],
        ];
        parent::init();
    }
}
