<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * UniversitiesFixture
 */
class UniversitiesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de universidad', 'autoIncrement' => true, 'precision' => null],
        'ruc_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'RUC de universidad', 'precision' => null],
        'name_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre de la Universidad', 'precision' => null],
        'address_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Direccion de la universidad', 'precision' => null],
        'phone_university' => ['type' => 'string', 'length' => 10, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Telefono fijo de la universidad.', 'precision' => null],
        'cellphone_university' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular de la universidad', 'precision' => null],
        'domain_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Dominio web de la universidad.', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_university'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_university' => 1,
                'ruc_university' => 'Lorem ipsum dolor sit amet',
                'name_university' => 'Lorem ipsum dolor sit amet',
                'address_university' => 'Lorem ipsum dolor sit amet',
                'phone_university' => 'Lorem ip',
                'cellphone_university' => 'Lorem i',
                'domain_university' => 'Lorem ipsum dolor sit amet',
                'created' => '2020-05-10 03:57:55',
                'modified' => '2020-05-10 03:57:55',
            ],
        ];
        parent::init();
    }
}
