<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * TeachersFixture
 */
class TeachersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de profesor', 'autoIncrement' => true, 'precision' => null],
        'dni_teacher' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del profesor', 'precision' => null],
        'name_teacher' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del profesor', 'precision' => null],
        'lastname_teacher' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del profesor', 'precision' => null],
        'email_teacher' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Correo del profesor', 'precision' => null],
        'cellphone_teacher' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del profesor', 'precision' => null],
        'status_teacher' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si el profesor esta activo', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_teacher'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_teacher' => 1,
                'dni_teacher' => 'Lorem ',
                'name_teacher' => 'Lorem ipsum dolor sit amet',
                'lastname_teacher' => 'Lorem ipsum dolor sit amet',
                'email_teacher' => 'Lorem ipsum dolor sit amet',
                'cellphone_teacher' => 'Lorem i',
                'status_teacher' => 1,
                'created' => '2020-05-10 04:01:28',
                'modified' => '2020-05-10 04:01:28',
            ],
        ];
        parent::init();
    }
}
