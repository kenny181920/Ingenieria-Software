<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * CoordinatorsFixture
 */
class CoordinatorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_coordinator' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de coordinador', 'autoIncrement' => true, 'precision' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'coordinators_FK_schools', 'precision' => null, 'autoIncrement' => null],
        'dni_coordinator' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del coordinador', 'precision' => null],
        'name_coordinator' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del coordinador', 'precision' => null],
        'lastname_coordinator' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del coordinador', 'precision' => null],
        'email_coordinator' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Correo del coordinador', 'precision' => null],
        'cellphone_coordinator' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del coordinador', 'precision' => null],
        'status_coordinator' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si el coordinador esta activo', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_indexes' => [
            'id_school' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_coordinator'], 'length' => []],
            'coordinators_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_coordinator' => 1,
                'id_school' => 1,
                'dni_coordinator' => 'Lorem ',
                'name_coordinator' => 'Lorem ipsum dolor sit amet',
                'lastname_coordinator' => 'Lorem ipsum dolor sit amet',
                'email_coordinator' => 'Lorem ipsum dolor sit amet',
                'cellphone_coordinator' => 'Lorem i',
                'status_coordinator' => 1,
                'created' => '2020-05-10 04:00:35',
                'modified' => '2020-05-10 04:00:35',
            ],
        ];
        parent::init();
    }
}
