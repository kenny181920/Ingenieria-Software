<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DirectorsFixture
 */
class DirectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_director' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de Director', 'autoIncrement' => true, 'precision' => null],
        'id_department' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK departamentos', 'precision' => null, 'autoIncrement' => null],
        'dni_director' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del director', 'precision' => null],
        'name_director' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del director', 'precision' => null],
        'lastname_director' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del director', 'precision' => null],
        'email_director' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Correo del director.', 'precision' => null],
        'cellphone_director' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del director.', 'precision' => null],
        'status_director' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si esta activo el director', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion'],
        '_indexes' => [
            'id_department' => ['type' => 'index', 'columns' => ['id_department'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_director'], 'length' => []],
            'directors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_department'], 'references' => ['departments', 'id_department'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_director' => 1,
                'id_department' => 1,
                'dni_director' => 'Lorem ',
                'name_director' => 'Lorem ipsum dolor sit amet',
                'lastname_director' => 'Lorem ipsum dolor sit amet',
                'email_director' => 'Lorem ipsum dolor sit amet',
                'cellphone_director' => 'Lorem i',
                'status_director' => 1,
                'created' => '2020-05-10 04:00:22',
                'modified' => '2020-05-10 04:00:22',
            ],
        ];
        parent::init();
    }
}
