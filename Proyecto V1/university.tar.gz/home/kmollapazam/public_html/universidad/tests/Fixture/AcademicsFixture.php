<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AcademicsFixture
 */
class AcademicsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de academico', 'autoIncrement' => true, 'precision' => null],
        'id_coordinator' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de coordinadores', 'precision' => null, 'autoIncrement' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de escuelas', 'precision' => null, 'autoIncrement' => null],
        'year_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Año academico.', 'precision' => null, 'autoIncrement' => null],
        'period_academic' => ['type' => 'string', 'length' => 2, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Periodo del anio academico.', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion'],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.'],
        '_indexes' => [
            'id_coordinator' => ['type' => 'index', 'columns' => ['id_coordinator'], 'length' => []],
            'id_school' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_academic'], 'length' => []],
            'academics_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_coordinator'], 'references' => ['coordinators', 'id_coordinator'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'academics_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_academic' => 1,
                'id_coordinator' => 1,
                'id_school' => 1,
                'year_academic' => 1,
                'period_academic' => 'Lo',
                'created' => '2020-05-10 04:00:50',
                'modified' => '2020-05-10 04:00:50',
            ],
        ];
        parent::init();
    }
}
