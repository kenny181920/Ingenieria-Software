<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\AcademicsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\AcademicsTable Test Case
 */
class AcademicsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\AcademicsTable
     */
    protected $Academics;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Academics',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Academics') ? [] : ['className' => AcademicsTable::class];
        $this->Academics = TableRegistry::getTableLocator()->get('Academics', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Academics);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
