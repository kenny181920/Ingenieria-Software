<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\RectorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\RectorsTable Test Case
 */
class RectorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\RectorsTable
     */
    protected $Rectors;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Rectors',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Rectors') ? [] : ['className' => RectorsTable::class];
        $this->Rectors = TableRegistry::getTableLocator()->get('Rectors', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Rectors);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
