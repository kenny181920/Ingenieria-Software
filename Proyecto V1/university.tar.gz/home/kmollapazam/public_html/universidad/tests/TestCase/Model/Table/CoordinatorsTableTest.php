<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\CoordinatorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\CoordinatorsTable Test Case
 */
class CoordinatorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\CoordinatorsTable
     */
    protected $Coordinators;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Coordinators',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Coordinators') ? [] : ['className' => CoordinatorsTable::class];
        $this->Coordinators = TableRegistry::getTableLocator()->get('Coordinators', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Coordinators);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
