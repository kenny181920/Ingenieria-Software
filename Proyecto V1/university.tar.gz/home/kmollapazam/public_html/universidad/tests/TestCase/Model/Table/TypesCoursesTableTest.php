<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TypesCoursesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TypesCoursesTable Test Case
 */
class TypesCoursesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TypesCoursesTable
     */
    protected $TypesCourses;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.TypesCourses',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('TypesCourses') ? [] : ['className' => TypesCoursesTable::class];
        $this->TypesCourses = TableRegistry::getTableLocator()->get('TypesCourses', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->TypesCourses);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
