<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AssignmentsFixture
 */
class AssignmentsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_assignment' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de asignacion', 'autoIncrement' => true, 'precision' => null],
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de academico', 'precision' => null, 'autoIncrement' => null],
        'id_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de cursos', 'precision' => null, 'autoIncrement' => null],
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de profesor', 'precision' => null, 'autoIncrement' => null],
        'id_turn' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de shifts', 'precision' => null, 'autoIncrement' => null],
        'id_section' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de secciones', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_academic' => ['type' => 'index', 'columns' => ['id_academic'], 'length' => []],
            'id_course' => ['type' => 'index', 'columns' => ['id_course'], 'length' => []],
            'id_teacher' => ['type' => 'index', 'columns' => ['id_teacher'], 'length' => []],
            'id_turn' => ['type' => 'index', 'columns' => ['id_turn'], 'length' => []],
            'id_section' => ['type' => 'index', 'columns' => ['id_section'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_assignment'], 'length' => []],
            'assignments_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_academic'], 'references' => ['academics', 'id_academic'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_course'], 'references' => ['courses', 'id_course'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_teacher'], 'references' => ['teachers', 'id_teacher'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_4' => ['type' => 'foreign', 'columns' => ['id_turn'], 'references' => ['shifts', 'id_turn'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_5' => ['type' => 'foreign', 'columns' => ['id_section'], 'references' => ['sections', 'id_section'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_assignment' => 1,
                'id_academic' => 1,
                'id_course' => 1,
                'id_teacher' => 1,
                'id_turn' => 1,
                'id_section' => 1,
                'created' => '2020-05-27 07:26:39',
                'modified' => '2020-05-27 07:26:39',
            ],
        ];
        parent::init();
    }
}
