<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DeansFixture
 */
class DeansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_dean' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de decanos', 'precision' => null, 'autoIncrement' => null],
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de facultades', 'precision' => null, 'autoIncrement' => null],
        'dni_dean' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del decano', 'precision' => null, 'fixed' => null],
        'name_dean' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del decano.', 'precision' => null, 'fixed' => null],
        'lastname_dean' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellido del decano.', 'precision' => null, 'fixed' => null],
        'cellphone_dean' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del decano', 'precision' => null, 'fixed' => null],
        'status_dean' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si el decano esta activo', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id usuario', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_user' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'id_faculty' => ['type' => 'index', 'columns' => ['id_faculty'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_dean'], 'length' => []],
            'deans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'deans_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_faculty'], 'references' => ['faculties', 'id_faculty'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_dean' => 1,
                'id_faculty' => 1,
                'dni_dean' => 'Lorem ',
                'name_dean' => 'Lorem ipsum dolor sit amet',
                'lastname_dean' => 'Lorem ipsum dolor sit amet',
                'cellphone_dean' => 'Lorem i',
                'status_dean' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 07:26:34',
                'modified' => '2020-05-27 07:26:34',
            ],
        ];
        parent::init();
    }
}
