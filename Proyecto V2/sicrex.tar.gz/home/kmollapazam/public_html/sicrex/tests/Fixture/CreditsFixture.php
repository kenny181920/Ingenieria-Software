<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * CreditsFixture
 */
class CreditsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_credit' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id creditos', 'autoIncrement' => true, 'precision' => null],
        'id_talk' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id charla', 'precision' => null, 'autoIncrement' => null],
        'id_workshop' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id taller', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_talk' => ['type' => 'index', 'columns' => ['id_talk'], 'length' => []],
            'id_workshop' => ['type' => 'index', 'columns' => ['id_workshop'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_credit'], 'length' => []],
            'credits_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_talk'], 'references' => ['talks', 'id_talk'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'credits_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_workshop'], 'references' => ['workshops', 'id_workshop'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_credit' => 1,
                'id_talk' => 1,
                'id_workshop' => 1,
                'created' => '2020-05-27 07:26:36',
                'modified' => '2020-05-27 07:26:36',
            ],
        ];
        parent::init();
    }
}
