<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * UniversitiesFixture
 */
class UniversitiesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de universidad', 'autoIncrement' => true, 'precision' => null],
        'ruc_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'RUC de universidad', 'precision' => null, 'fixed' => null],
        'name_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre de la Universidad', 'precision' => null, 'fixed' => null],
        'address_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Direccion de la universidad', 'precision' => null, 'fixed' => null],
        'phone_university' => ['type' => 'string', 'length' => 10, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Telefono fijo de la universidad.', 'precision' => null, 'fixed' => null],
        'cellphone_university' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular de la universidad', 'precision' => null, 'fixed' => null],
        'domain_university' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Dominio web de la universidad.', 'precision' => null, 'fixed' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion', 'precision' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_university'], 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_university' => 1,
                'ruc_university' => 'Lorem ipsum dolor sit amet',
                'name_university' => 'Lorem ipsum dolor sit amet',
                'address_university' => 'Lorem ipsum dolor sit amet',
                'phone_university' => 'Lorem ip',
                'cellphone_university' => 'Lorem i',
                'domain_university' => 'Lorem ipsum dolor sit amet',
                'created' => '2020-05-27 07:26:34',
                'modified' => '2020-05-27 07:26:34',
            ],
        ];
        parent::init();
    }
}
