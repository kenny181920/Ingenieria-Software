<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * FacultiesFixture
 */
class FacultiesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de la facultad', 'autoIncrement' => true, 'precision' => null],
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de universidades', 'precision' => null, 'autoIncrement' => null],
        'name_faculty' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre de la facultad', 'precision' => null, 'fixed' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_university' => ['type' => 'index', 'columns' => ['id_university'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_faculty'], 'length' => []],
            'faculties_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_university'], 'references' => ['universities', 'id_university'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_faculty' => 1,
                'id_university' => 1,
                'name_faculty' => 'Lorem ipsum dolor sit amet',
                'created' => '2020-05-27 07:26:34',
                'modified' => '2020-05-27 07:26:34',
            ],
        ];
        parent::init();
    }
}
