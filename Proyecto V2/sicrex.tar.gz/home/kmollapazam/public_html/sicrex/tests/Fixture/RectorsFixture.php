<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * RectorsFixture
 */
class RectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_rector' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de Rectores', 'autoIncrement' => true, 'precision' => null],
        'dni_rector' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del Rector', 'precision' => null, 'fixed' => null],
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de universidades', 'precision' => null, 'autoIncrement' => null],
        'name_rector' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del Rector', 'precision' => null, 'fixed' => null],
        'lastname_rector' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del Rector', 'precision' => null, 'fixed' => null],
        'cellphone_rector' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del rector.', 'precision' => null, 'fixed' => null],
        'status_rector' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si esta activo el rector', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id usuario', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion', 'precision' => null],
        '_indexes' => [
            'id_user' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'id_university' => ['type' => 'index', 'columns' => ['id_university'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_rector'], 'length' => []],
            'rectors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'rectors_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_university'], 'references' => ['universities', 'id_university'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_rector' => 1,
                'dni_rector' => 'Lorem ',
                'id_university' => 1,
                'name_rector' => 'Lorem ipsum dolor sit amet',
                'lastname_rector' => 'Lorem ipsum dolor sit amet',
                'cellphone_rector' => 'Lorem i',
                'status_rector' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 07:26:34',
                'modified' => '2020-05-27 07:26:34',
            ],
        ];
        parent::init();
    }
}
