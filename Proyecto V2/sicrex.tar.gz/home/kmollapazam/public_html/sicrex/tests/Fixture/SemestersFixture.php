<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SemestersFixture
 */
class SemestersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codico unico del semestre', 'autoIncrement' => true, 'precision' => null],
        'id_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de plan de estudios', 'precision' => null, 'autoIncrement' => null],
        'number_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Numero de semestre', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_study_plan' => ['type' => 'index', 'columns' => ['id_study_plan'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_semester'], 'length' => []],
            'semesters_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_study_plan'], 'references' => ['study_plans', 'id_study_plan'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_semester' => 1,
                'id_study_plan' => 1,
                'number_semester' => 1,
                'created' => '2020-05-27 07:26:37',
                'modified' => '2020-05-27 07:26:37',
            ],
        ];
        parent::init();
    }
}
