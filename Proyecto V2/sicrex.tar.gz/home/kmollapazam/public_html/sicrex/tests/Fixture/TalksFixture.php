<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * TalksFixture
 */
class TalksFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_talk' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id charla', 'autoIncrement' => true, 'precision' => null],
        'name_talk' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de la charla', 'precision' => null, 'fixed' => null],
        'date_talk' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de la charla', 'precision' => null],
        'number_credit_talk' => ['type' => 'decimal', 'length' => 3, 'precision' => 2, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Cantidad de creditos de la charla'],
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id de facultad', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_faculty' => ['type' => 'index', 'columns' => ['id_faculty'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_talk'], 'length' => []],
            'talks_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_faculty'], 'references' => ['faculties', 'id_faculty'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_talk' => 1,
                'name_talk' => 'Lorem ipsum dolor sit amet',
                'date_talk' => '2020-05-27 07:26:35',
                'number_credit_talk' => 1.5,
                'id_faculty' => 1,
                'created' => '2020-05-27 07:26:35',
                'modified' => '2020-05-27 07:26:35',
            ],
        ];
        parent::init();
    }
}
