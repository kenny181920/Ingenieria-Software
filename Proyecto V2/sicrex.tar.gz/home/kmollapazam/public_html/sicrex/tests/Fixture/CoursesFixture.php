<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * CoursesFixture
 */
class CoursesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de curso', 'autoIncrement' => true, 'precision' => null],
        'id_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK semestres', 'precision' => null, 'autoIncrement' => null],
        'id_type_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de tipos de curso', 'precision' => null, 'autoIncrement' => null],
        'name_course' => ['type' => 'string', 'length' => 50, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del curso', 'precision' => null, 'fixed' => null],
        'credit_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Numero de creditos del curso', 'precision' => null, 'autoIncrement' => null],
        'hours_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Numero de horas del curso.', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_semester' => ['type' => 'index', 'columns' => ['id_semester'], 'length' => []],
            'id_type_course' => ['type' => 'index', 'columns' => ['id_type_course'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_course'], 'length' => []],
            'courses_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_semester'], 'references' => ['semesters', 'id_semester'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'courses_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_type_course'], 'references' => ['types_courses', 'id_type_course'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_course' => 1,
                'id_semester' => 1,
                'id_type_course' => 1,
                'name_course' => 'Lorem ipsum dolor sit amet',
                'credit_course' => 1,
                'hours_course' => 1,
                'created' => '2020-05-27 07:26:37',
                'modified' => '2020-05-27 07:26:37',
            ],
        ];
        parent::init();
    }
}
