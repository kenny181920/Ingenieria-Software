<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * StudentsFixture
 */
class StudentsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_student' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de estudiantes', 'autoIncrement' => true, 'precision' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK de escuelas', 'precision' => null, 'autoIncrement' => null],
        'dni_student' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del estudiante', 'precision' => null, 'fixed' => null],
        'name_student' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del estudiante', 'precision' => null, 'fixed' => null],
        'lastname_student' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del estudiante', 'precision' => null, 'fixed' => null],
        'address_student' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Direccion del estudiante', 'precision' => null, 'fixed' => null],
        'birthdate_student' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Cumpleaños del estudiante', 'precision' => null],
        'cellphone_student' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del estudiante', 'precision' => null, 'fixed' => null],
        'status_student' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si el estudiante esta activo', 'precision' => null],
        'id_credit' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK creditos', 'precision' => null, 'autoIncrement' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id usuario', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion', 'precision' => null],
        '_indexes' => [
            'id_school' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
            'id_user' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'id_credit' => ['type' => 'index', 'columns' => ['id_credit'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_student'], 'length' => []],
            'students_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'students_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'students_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_credit'], 'references' => ['credits', 'id_credit'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_student' => 1,
                'id_school' => 1,
                'dni_student' => 'Lorem ',
                'name_student' => 'Lorem ipsum dolor sit amet',
                'lastname_student' => 'Lorem ipsum dolor sit amet',
                'address_student' => 'Lorem ipsum dolor sit amet',
                'birthdate_student' => '2020-05-27 07:26:36',
                'cellphone_student' => 'Lorem i',
                'status_student' => 1,
                'id_credit' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 07:26:36',
                'modified' => '2020-05-27 07:26:36',
            ],
        ];
        parent::init();
    }
}
