<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DirectorsFixture
 */
class DirectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_director' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ID de Director', 'autoIncrement' => true, 'precision' => null],
        'id_department' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'FK departamentos', 'precision' => null, 'autoIncrement' => null],
        'dni_director' => ['type' => 'string', 'length' => 8, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'DNI del director', 'precision' => null, 'fixed' => null],
        'name_director' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Nombre del director', 'precision' => null, 'fixed' => null],
        'lastname_director' => ['type' => 'string', 'length' => 200, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Apellidos del director', 'precision' => null, 'fixed' => null],
        'cellphone_director' => ['type' => 'string', 'length' => 9, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular del director.', 'precision' => null, 'fixed' => null],
        'status_director' => ['type' => 'boolean', 'length' => null, 'null' => true, 'default' => '1', 'comment' => 'Si esta activo el director', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK id usuario', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion', 'precision' => null],
        '_indexes' => [
            'id_user' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'id_department' => ['type' => 'index', 'columns' => ['id_department'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_director'], 'length' => []],
            'directors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'directors_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_department'], 'references' => ['departments', 'id_department'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_director' => 1,
                'id_department' => 1,
                'dni_director' => 'Lorem ',
                'name_director' => 'Lorem ipsum dolor sit amet',
                'lastname_director' => 'Lorem ipsum dolor sit amet',
                'cellphone_director' => 'Lorem i',
                'status_director' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 07:26:35',
                'modified' => '2020-05-27 07:26:35',
            ],
        ];
        parent::init();
    }
}
