<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * WorkshopsFixture
 */
class WorkshopsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_workshop' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id taller', 'autoIncrement' => true, 'precision' => null],
        'name_workshop' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre del taller', 'precision' => null, 'fixed' => null],
        'number_credit_workshop' => ['type' => 'decimal', 'length' => 3, 'precision' => 2, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Cantidad de creditos del taller'],
        'name_period_workshop' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar codigo de semestre ejemplo 2020-1', 'precision' => null, 'fixed' => null],
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'FK codigo docente', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de creacion.', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'Fecha de modificacion.', 'precision' => null],
        '_indexes' => [
            'id_teacher' => ['type' => 'index', 'columns' => ['id_teacher'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_workshop'], 'length' => []],
            'workshops_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_teacher'], 'references' => ['teachers', 'id_teacher'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_workshop' => 1,
                'name_workshop' => 'Lorem ipsum dolor sit amet',
                'number_credit_workshop' => 1.5,
                'name_period_workshop' => 'Lorem ipsum dolor sit amet',
                'id_teacher' => 1,
                'created' => '2020-05-27 07:26:36',
                'modified' => '2020-05-27 07:26:36',
            ],
        ];
        parent::init();
    }
}
