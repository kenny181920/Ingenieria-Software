<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * University Entity
 *
 * @property int $id_university
 * @property string $ruc_university
 * @property string $name_university
 * @property string $address_university
 * @property string $phone_university
 * @property string $cellphone_university
 * @property string $domain_university
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class University extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'ruc_university' => true,
        'name_university' => true,
        'address_university' => true,
        'phone_university' => true,
        'cellphone_university' => true,
        'domain_university' => true,
        'created' => true,
        'modified' => true,
    ];
}
