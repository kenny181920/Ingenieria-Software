<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Dean Entity
 *
 * @property int $id_dean
 * @property int $id_faculty
 * @property string $dni_dean
 * @property string $name_dean
 * @property string $lastname_dean
 * @property string $cellphone_dean
 * @property bool|null $status_dean
 * @property int|null $id_user
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Dean extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_faculty' => true,
        'dni_dean' => true,
        'name_dean' => true,
        'lastname_dean' => true,
        'cellphone_dean' => true,
        'status_dean' => true,
        'id_user' => true,
        'created' => true,
        'modified' => true,
    ];
}
