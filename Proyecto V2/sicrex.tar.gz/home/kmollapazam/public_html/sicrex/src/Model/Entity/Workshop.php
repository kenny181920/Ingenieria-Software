<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Workshop Entity
 *
 * @property int $id_workshop
 * @property string $name_workshop
 * @property float $number_credit_workshop
 * @property string $name_period_workshop
 * @property int|null $id_teacher
 * @property \Cake\I18n\FrozenTime $created
 * @property \Cake\I18n\FrozenTime $modified
 */
class Workshop extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'name_workshop' => true,
        'number_credit_workshop' => true,
        'name_period_workshop' => true,
        'id_teacher' => true,
        'created' => true,
        'modified' => true,
    ];
}
