<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Talks Model
 *
 * @method \App\Model\Entity\Talk get($primaryKey, $options = [])
 * @method \App\Model\Entity\Talk newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Talk[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Talk|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Talk saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Talk patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Talk[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Talk findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class TalksTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('talks');
        $this->setDisplayField('id_talk');
        $this->setPrimaryKey('id_talk');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_talk')
            ->allowEmptyString('id_talk', null, 'create');

        $validator
            ->scalar('name_talk')
            ->maxLength('name_talk', 255)
            ->requirePresence('name_talk', 'create')
            ->notEmptyString('name_talk');

        $validator
            ->dateTime('date_talk')
            ->requirePresence('date_talk', 'create')
            ->notEmptyDateTime('date_talk');

        $validator
            ->decimal('number_credit_talk')
            ->requirePresence('number_credit_talk', 'create')
            ->notEmptyString('number_credit_talk');

        $validator
            ->integer('id_faculty')
            ->allowEmptyString('id_faculty');

        return $validator;
    }
}
