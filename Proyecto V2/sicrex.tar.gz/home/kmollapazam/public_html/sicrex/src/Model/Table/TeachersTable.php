<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Teachers Model
 *
 * @method \App\Model\Entity\Teacher get($primaryKey, $options = [])
 * @method \App\Model\Entity\Teacher newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Teacher[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Teacher|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Teacher saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Teacher patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Teacher[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Teacher findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class TeachersTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('teachers');
        $this->setDisplayField('id_teacher');
        $this->setPrimaryKey('id_teacher');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_teacher')
            ->allowEmptyString('id_teacher', null, 'create');

        $validator
            ->scalar('dni_teacher')
            ->maxLength('dni_teacher', 8)
            ->requirePresence('dni_teacher', 'create')
            ->notEmptyString('dni_teacher');

        $validator
            ->scalar('name_teacher')
            ->maxLength('name_teacher', 200)
            ->requirePresence('name_teacher', 'create')
            ->notEmptyString('name_teacher');

        $validator
            ->scalar('lastname_teacher')
            ->maxLength('lastname_teacher', 200)
            ->requirePresence('lastname_teacher', 'create')
            ->notEmptyString('lastname_teacher');

        $validator
            ->scalar('cellphone_teacher')
            ->maxLength('cellphone_teacher', 9)
            ->requirePresence('cellphone_teacher', 'create')
            ->notEmptyString('cellphone_teacher');

        $validator
            ->boolean('status_teacher')
            ->allowEmptyString('status_teacher');

        $validator
            ->integer('id_user')
            ->allowEmptyString('id_user');

        return $validator;
    }
}
