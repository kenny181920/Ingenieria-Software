<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Universities Model
 *
 * @method \App\Model\Entity\University get($primaryKey, $options = [])
 * @method \App\Model\Entity\University newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\University[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\University|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\University saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\University patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\University[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\University findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UniversitiesTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('universities');
        $this->setDisplayField('id_university');
        $this->setPrimaryKey('id_university');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_university')
            ->allowEmptyString('id_university', null, 'create');

        $validator
            ->scalar('ruc_university')
            ->maxLength('ruc_university', 200)
            ->requirePresence('ruc_university', 'create')
            ->notEmptyString('ruc_university');

        $validator
            ->scalar('name_university')
            ->maxLength('name_university', 200)
            ->requirePresence('name_university', 'create')
            ->notEmptyString('name_university');

        $validator
            ->scalar('address_university')
            ->maxLength('address_university', 200)
            ->requirePresence('address_university', 'create')
            ->notEmptyString('address_university');

        $validator
            ->scalar('phone_university')
            ->maxLength('phone_university', 10)
            ->requirePresence('phone_university', 'create')
            ->notEmptyString('phone_university');

        $validator
            ->scalar('cellphone_university')
            ->maxLength('cellphone_university', 9)
            ->requirePresence('cellphone_university', 'create')
            ->notEmptyString('cellphone_university');

        $validator
            ->scalar('domain_university')
            ->maxLength('domain_university', 200)
            ->requirePresence('domain_university', 'create')
            ->notEmptyString('domain_university');

        return $validator;
    }
}
