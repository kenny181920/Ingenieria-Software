<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Workshops Model
 *
 * @method \App\Model\Entity\Workshop get($primaryKey, $options = [])
 * @method \App\Model\Entity\Workshop newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Workshop[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Workshop|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Workshop saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Workshop patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Workshop[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Workshop findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class WorkshopsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('workshops');
        $this->setDisplayField('id_workshop');
        $this->setPrimaryKey('id_workshop');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_workshop')
            ->allowEmptyString('id_workshop', null, 'create');

        $validator
            ->scalar('name_workshop')
            ->maxLength('name_workshop', 255)
            ->requirePresence('name_workshop', 'create')
            ->notEmptyString('name_workshop');

        $validator
            ->decimal('number_credit_workshop')
            ->requirePresence('number_credit_workshop', 'create')
            ->notEmptyString('number_credit_workshop');

        $validator
            ->scalar('name_period_workshop')
            ->maxLength('name_period_workshop', 255)
            ->requirePresence('name_period_workshop', 'create')
            ->notEmptyString('name_period_workshop');

        $validator
            ->integer('id_teacher')
            ->allowEmptyString('id_teacher');

        return $validator;
    }
}
