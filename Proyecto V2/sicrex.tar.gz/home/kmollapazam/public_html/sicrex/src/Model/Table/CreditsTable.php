<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Credits Model
 *
 * @method \App\Model\Entity\Credit get($primaryKey, $options = [])
 * @method \App\Model\Entity\Credit newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Credit[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Credit|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Credit saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Credit patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Credit[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Credit findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class CreditsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('credits');
        $this->setDisplayField('id_credit');
        $this->setPrimaryKey('id_credit');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_credit')
            ->allowEmptyString('id_credit', null, 'create');

        $validator
            ->integer('id_talk')
            ->allowEmptyString('id_talk');

        $validator
            ->integer('id_workshop')
            ->allowEmptyString('id_workshop');

        return $validator;
    }
}
