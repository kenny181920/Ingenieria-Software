<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Deans Model
 *
 * @method \App\Model\Entity\Dean get($primaryKey, $options = [])
 * @method \App\Model\Entity\Dean newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Dean[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Dean|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Dean saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Dean patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Dean[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Dean findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DeansTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('deans');
        $this->setDisplayField('id_dean');
        $this->setPrimaryKey('id_dean');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_dean')
            ->allowEmptyString('id_dean', null, 'create');

        $validator
            ->integer('id_faculty')
            ->requirePresence('id_faculty', 'create')
            ->notEmptyString('id_faculty');

        $validator
            ->scalar('dni_dean')
            ->maxLength('dni_dean', 8)
            ->requirePresence('dni_dean', 'create')
            ->notEmptyString('dni_dean');

        $validator
            ->scalar('name_dean')
            ->maxLength('name_dean', 200)
            ->requirePresence('name_dean', 'create')
            ->notEmptyString('name_dean');

        $validator
            ->scalar('lastname_dean')
            ->maxLength('lastname_dean', 200)
            ->requirePresence('lastname_dean', 'create')
            ->notEmptyString('lastname_dean');

        $validator
            ->scalar('cellphone_dean')
            ->maxLength('cellphone_dean', 9)
            ->requirePresence('cellphone_dean', 'create')
            ->notEmptyString('cellphone_dean');

        $validator
            ->boolean('status_dean')
            ->allowEmptyString('status_dean');

        $validator
            ->integer('id_user')
            ->allowEmptyString('id_user');

        return $validator;
    }
}
