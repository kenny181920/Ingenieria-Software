<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Workshops Controller
 *
 * @property \App\Model\Table\WorkshopsTable $Workshops
 *
 * @method \App\Model\Entity\Workshop[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class WorkshopsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $workshops = $this->paginate($this->Workshops);

        $this->set(compact('workshops'));
    }

    /**
     * View method
     *
     * @param string|null $id Workshop id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $workshop = $this->Workshops->get($id, [
            'contain' => [],
        ]);

        $this->set('workshop', $workshop);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $workshop = $this->Workshops->newEntity();
        if ($this->request->is('post')) {
            $workshop = $this->Workshops->patchEntity($workshop, $this->request->getData());
            if ($this->Workshops->save($workshop)) {
                $this->Flash->success(__('The workshop has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The workshop could not be saved. Please, try again.'));
        }
        $this->set(compact('workshop'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Workshop id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $workshop = $this->Workshops->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $workshop = $this->Workshops->patchEntity($workshop, $this->request->getData());
            if ($this->Workshops->save($workshop)) {
                $this->Flash->success(__('The workshop has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The workshop could not be saved. Please, try again.'));
        }
        $this->set(compact('workshop'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Workshop id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $workshop = $this->Workshops->get($id);
        if ($this->Workshops->delete($workshop)) {
            $this->Flash->success(__('The workshop has been deleted.'));
        } else {
            $this->Flash->error(__('The workshop could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
